#include<stdio.h>
int main(){
    int winsize, sent = 0, i, ack;
    printf("enter the window size");
    scanf("%d", &winsize);
    while (1)
    {
        for (i = 1; i <= winsize;i++){
            printf("frame %d transmitted\n", sent+1);
            sent++;
            if(sent==winsize){
                break;
            }}
            printf("Enter the last recieved ack \n");
            scanf("%d", &ack);
            if(ack==winsize){
                break;
            }
            else{
                sent = ack;
                sent = sent - 1;
            }
    }
    }
